// ============================================================
// AUTO-GENERATED — DO NOT EDIT
// Event map: ten event -> { request, response } types
// ============================================================

import type {
  AppOpenWebviewRequest,
  AppOpenWebviewResponse,
  AppOpenStoreRequest,
  AppOpenStoreResponse,
  ExitRequest,
  ExitResponse,
  OpenExternalLinkRequest,
  OpenExternalLinkResponse,
  OpenMiniAppRequest,
  OpenMiniAppResponse,
  RequestMultipleUserDataPermissionRequest,
  RequestMultipleUserDataPermissionResponse
} from './types.generated';

/** Map event name -> [RequestType, ResponseType] */
export interface MiniAppEventMap {
  'APP_OPEN_WEBVIEW': [AppOpenWebviewRequest, AppOpenWebviewResponse];
  'APP_OPEN_STORE': [AppOpenStoreRequest, AppOpenStoreResponse];
  'EXIT': [ExitRequest, ExitResponse];
  'OPEN_EXTERNAL_LINK': [OpenExternalLinkRequest, OpenExternalLinkResponse];
  'OPEN_MINI_APP': [OpenMiniAppRequest, OpenMiniAppResponse];
  'REQUEST_MULTIPLE_USER_DATA_PERMISSION': [RequestMultipleUserDataPermissionRequest, RequestMultipleUserDataPermissionResponse];
}

/** Danh sach event name constants */
export const MINIAPP_EVENTS = {
  /** Mở một WebView mới với URL và cấu hình tùy chỉnh. */
  appOpenWebview: 'APP_OPEN_WEBVIEW' as const,
  /** Mở ứng dụng từ App Store/Google Play hoặc launch app đã cài. */
  appOpenStore: 'APP_OPEN_STORE' as const,
  /** Đóng Mini App và điều hướng về màn hình khác. */
  exit: 'EXIT' as const,
  /** Mở URL bằng browser mặc định của hệ thống. */
  openExternalLink: 'OPEN_EXTERNAL_LINK' as const,
  /** Mở một Mini App khác từ Mini App hiện tại. */
  openMiniApp: 'OPEN_MINI_APP' as const,
  /** Yêu cầu nhiều quyền user data cùng một lúc. */
  requestMultipleUserDataPermission: 'REQUEST_MULTIPLE_USER_DATA_PERMISSION' as const,
};
